// TODO(vm): Rm this file once #3759 is merged.
import { useWeb3React } from '@web3-react/core'

export default function useActiveWeb3React() {
  return useWeb3React()
}
