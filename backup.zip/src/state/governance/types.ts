export enum VoteOption {
  Against,
  For,
  Abstain,
}
